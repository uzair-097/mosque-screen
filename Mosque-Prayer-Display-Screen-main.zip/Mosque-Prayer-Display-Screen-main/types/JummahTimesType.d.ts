export type JummahTimes = JummahTime[]

export interface JummahTime {
  label: string
  time: string
}
